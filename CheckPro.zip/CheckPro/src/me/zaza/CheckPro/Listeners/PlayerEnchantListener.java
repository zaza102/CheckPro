package me.zaza.CheckPro.Listeners;

import me.zaza.CheckPro.CheckPro;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.enchantment.PrepareItemEnchantEvent;

public class PlayerEnchantListener implements Listener
{
	
	private final String denyMessage = CheckPro.MSGes.getString("MSG.EnchantingDenyMessage");
	
	@EventHandler
	public void onPlayerEnchanting(PrepareItemEnchantEvent e)
	{
		Player p = e.getEnchanter();
		if(!p.hasPermission("CheckPro.allow.*") && !p.isOp() && !p.hasPermission("CheckPro.allow.enchant." + e.getItem().getType()))
		{
			p.sendMessage("�3[CheckPro]" + "�4 " + denyMessage);
			e.setCancelled(true);
		}		
	}
}
